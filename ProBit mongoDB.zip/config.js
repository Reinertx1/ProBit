module.exports = {
  token:"MTAwNTAyNzI0MjA3NTc1ODYxMw.Gqn9sH.lUVSeiSkt-DJkBM7kziipdYjTBKUVHc3V7k5eg",
  globalBot: true, // false => if bot is private bot - true => if bot isn't private bot
  guildID: "1034469502311747705",
}